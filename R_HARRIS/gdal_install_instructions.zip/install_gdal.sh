R CMD INSTALL sf_0.6-3.tar.gz \
--configure-args='-with-gdal-config=/Library/Frameworks/GDAL.framework/Versions/2.2/unix/bin/gdal-config -with-geos-config=/Library/Frameworks/GEOS.framework/Versions/3B/unix/bin/geos-config'
